package com.gymapp.net;

public class SessionContext {
    public static Role role;
    public static String id;
    public static String name;
    public static SocketClient client;
}
