package com.gymapp.net;

public enum MessageType {
    SESSION_JOIN,
    SESSION_LEAVE,
    PUBLIC_CHAT,
    NOTICE,
    PRIVATE_CHAT,
    TASK_ASSIGN,
    TASK_UPDATE
}
