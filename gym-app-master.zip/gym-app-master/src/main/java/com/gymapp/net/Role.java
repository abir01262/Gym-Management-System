package com.gymapp.net;

public enum Role {
    ADMIN, COACH, MEMBER
}
